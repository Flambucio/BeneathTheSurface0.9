#include "headers/Main.h"

int main()
{	
    BenTheSur::Main app;
    app.Run();
}
